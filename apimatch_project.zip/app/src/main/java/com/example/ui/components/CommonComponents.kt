package com.example.ui.components

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.seed.ApiCatalogSeed
import com.example.model.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.AppNavTab
import com.example.ui.viewmodel.MainViewModel
import com.example.util.StarterCodeGenerator

@Composable
fun ApimatchBoldHeader(
    isPro: Boolean,
    searchesLeft: Int,
    onAvatarClick: () -> Unit,
    onQuotaClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 20.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = "HI, DEV",
                color = AppWhite,
                fontSize = 22.sp,
                fontFamily = ArchivoFontFamily,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = (-0.5).sp
            )

            // 4/5 left pill
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = AppCardNav,
                modifier = Modifier
                    .clickable { onQuotaClick() }
                    .testTag("search_counter_pill")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .clip(CircleShape)
                            .background(if (isPro) AppBlue else AppYellow)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isPro) "PRO UNLIMITED" else "$searchesLeft/5 LEFT",
                        color = AppWhite,
                        fontSize = 11.sp,
                        fontFamily = ArchivoFontFamily,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 0.5.sp
                    )
                }
            }
        }

        // Yellow avatar
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(AppYellow)
                .clickable { onAvatarClick() }
                .testTag("header_avatar_button"),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Person,
                contentDescription = "Profile",
                tint = AppBackground,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}

@Composable
fun BoldFloatingBottomNav(
    currentTab: AppNavTab,
    isPro: Boolean,
    hasDownApi: Boolean,
    onTabSelected: (AppNavTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            shape = RoundedCornerShape(32.dp),
            color = AppCardNav,
            shadowElevation = 0.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 6.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val tabs = listOf(
                    AppNavTab.SEARCH to Icons.Default.Search,
                    AppNavTab.BROWSE to Icons.Default.GridView,
                    AppNavTab.WATCHLIST to Icons.Default.NotificationsActive,
                    AppNavTab.PROJECTS to Icons.Default.Folder
                )

                tabs.forEach { (tab, icon) ->
                    val isSelected = currentTab == tab
                    val interactionSource = remember { MutableInteractionSource() }
                    val isPressed by interactionSource.collectIsPressedAsState()
                    val scale by animateFloatAsState(
                        targetValue = if (isPressed) 0.95f else 1f,
                        animationSpec = tween(durationMillis = 200),
                        label = "tab_scale"
                    )

                    Box(
                        modifier = Modifier
                            .scale(scale)
                            .clip(RoundedCornerShape(26.dp))
                            .background(if (isSelected) AppBlue else Color.Transparent)
                            .clickable(
                                interactionSource = interactionSource,
                                indication = null
                            ) {
                                onTabSelected(tab)
                            }
                            .padding(horizontal = if (isSelected) 14.dp else 10.dp, vertical = 10.dp)
                            .testTag("nav_tab_${tab.name.lowercase()}"),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = tab.title,
                                    tint = if (isSelected) AppWhite else AppWhite.copy(alpha = 0.6f),
                                    modifier = Modifier.size(20.dp)
                                )
                                // Coral dot on Watchlist tab if an API is down
                                if (tab == AppNavTab.WATCHLIST && hasDownApi) {
                                    Box(
                                        modifier = Modifier
                                            .size(7.dp)
                                            .align(Alignment.TopEnd)
                                            .clip(CircleShape)
                                            .background(AppCoral)
                                    )
                                }
                            }

                            if (isSelected) {
                                Text(
                                    text = tab.title.uppercase(),
                                    color = AppWhite,
                                    fontSize = 12.sp,
                                    fontFamily = ArchivoFontFamily,
                                    fontWeight = FontWeight.ExtraBold,
                                    letterSpacing = 0.5.sp
                                )
                            }

                            // "PRO" tag on Watchlist for free users
                            if (tab == AppNavTab.WATCHLIST && !isPro && !isSelected) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(AppCoral)
                                        .padding(horizontal = 4.dp, vertical = 1.dp)
                                ) {
                                    Text(
                                        text = "PRO",
                                        color = AppBackground,
                                        fontSize = 8.sp,
                                        fontFamily = ArchivoFontFamily,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StatusChip(
    status: TestStatus,
    responseTimeMs: Long = 0L,
    isTesting: Boolean = false,
    contentColor: Color,
    modifier: Modifier = Modifier
) {
    val (label, dotColor) = when {
        isTesting -> "TESTING..." to AppYellow
        status == TestStatus.UP -> "UP • ${if (responseTimeMs > 0) "${responseTimeMs}ms" else "FAST"}" to AppBackground
        status == TestStatus.SLOW -> "SLOW • ${responseTimeMs}ms" to AppCoral
        status == TestStatus.DOWN -> "DOWN" to AppCoral
        status == TestStatus.CORS_RESTRICTED -> "CORS RESTRICTED" to AppCoral
        else -> "READY" to contentColor
    }

    Surface(
        shape = RoundedCornerShape(16.dp),
        color = AppBackground.copy(alpha = 0.85f),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(dotColor)
            )
            Text(
                text = label,
                color = AppWhite,
                fontSize = 11.sp,
                fontFamily = ArchivoFontFamily,
                fontWeight = FontWeight.ExtraBold
            )
        }
    }
}

@Composable
fun TagPill(
    text: String,
    contentColor: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, contentColor.copy(alpha = 0.7f), RoundedCornerShape(16.dp))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(
            text = text,
            color = contentColor,
            fontSize = 11.sp,
            fontFamily = ArchivoFontFamily,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun PrimaryPillButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: @Composable (() -> Unit)? = null
) {
    Button(
        onClick = onClick,
        shape = RoundedCornerShape(24.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = AppCoral,
            contentColor = AppBackground
        ),
        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 10.dp),
        modifier = modifier.height(44.dp)
    ) {
        if (icon != null) {
            icon()
            Spacer(modifier = Modifier.width(6.dp))
        }
        Text(
            text = text.uppercase(),
            fontSize = 13.sp,
            fontFamily = ArchivoFontFamily,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = 0.5.sp
        )
    }
}

@Composable
fun SecondaryPillButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: @Composable (() -> Unit)? = null
) {
    Button(
        onClick = onClick,
        shape = RoundedCornerShape(24.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = AppBackground,
            contentColor = AppWhite
        ),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
        modifier = modifier.height(44.dp)
    ) {
        if (icon != null) {
            icon()
            Spacer(modifier = Modifier.width(6.dp))
        }
        Text(
            text = text.uppercase(),
            fontSize = 13.sp,
            fontFamily = ArchivoFontFamily,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = 0.5.sp
        )
    }
}

@Composable
fun RoundBlackDocsButton(
    url: String,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    Box(
        modifier = modifier
            .size(42.dp)
            .clip(CircleShape)
            .background(AppBackground)
            .clickable {
                try {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                    context.startActivity(intent)
                } catch (e: Exception) {}
            },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "↗",
            color = AppWhite,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun ColoredApiCard(
    api: PublicApi,
    cardBgColor: Color,
    matchScore: Int? = null,
    pingResult: LivePingResult? = null,
    isPinging: Boolean = false,
    onTestLive: () -> Unit,
    onGetCode: () -> Unit,
    why: String? = null,
    miniPlan: List<String>? = null,
    modifier: Modifier = Modifier
) {
    val contentColor = getCardContentColor(cardBgColor)

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("colored_api_card_${api.id}"),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = cardBgColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            // Card Header: BIG UPPERCASE NAME + BLACK PILL (MATCH %)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = api.name.uppercase(),
                    color = contentColor,
                    fontSize = 20.sp,
                    fontFamily = ArchivoFontFamily,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = (-0.5).sp,
                    modifier = Modifier.weight(1f)
                )

                if (matchScore != null) {
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = AppBackground
                    ) {
                        Text(
                            text = "$matchScore%",
                            color = AppWhite,
                            fontSize = 12.sp,
                            fontFamily = ArchivoFontFamily,
                            fontWeight = FontWeight.ExtraBold,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Outlined Tags: category, "No key" / auth, "CORS: yes"
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TagPill(text = api.category.displayName.uppercase(), contentColor = contentColor)
                TagPill(
                    text = if (api.auth == AuthType.NONE) "NO KEY" else api.auth.displayName.uppercase(),
                    contentColor = contentColor
                )
                TagPill(
                    text = if (api.cors == CorsType.YES) "CORS: YES" else "CORS: NO",
                    contentColor = contentColor
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Description
            Text(
                text = api.description,
                color = contentColor.copy(alpha = 0.9f),
                fontSize = 15.sp,
                fontFamily = ArchivoFontFamily,
                fontWeight = FontWeight.Medium,
                lineHeight = 21.sp
            )

            // Why explanation if present
            if (!why.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "WHY: $why",
                    color = contentColor,
                    fontSize = 13.sp,
                    fontFamily = ArchivoFontFamily,
                    fontWeight = FontWeight.SemiBold
                )
            }

            // Mini plan
            if (miniPlan != null && miniPlan.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    miniPlan.forEachIndexed { i, step ->
                        Text(
                            text = "${i + 1}. $step",
                            color = contentColor.copy(alpha = 0.85f),
                            fontSize = 12.sp,
                            fontFamily = ArchivoFontFamily,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Status chip if available
            if (pingResult != null) {
                StatusChip(
                    status = pingResult.status,
                    responseTimeMs = pingResult.responseTimeMs,
                    isTesting = isPinging,
                    contentColor = contentColor
                )
                Spacer(modifier = Modifier.height(12.dp))
            }

            // Action row: Primary Button (coral pill) or Secondary Button + Docs round button ↗
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PrimaryPillButton(
                        text = if (isPinging) "PINGING..." else "TEST LIVE",
                        onClick = onTestLive,
                        icon = {
                            Icon(Icons.Default.Sensors, contentDescription = null, modifier = Modifier.size(16.dp))
                        }
                    )
                    SecondaryPillButton(
                        text = "CODE",
                        onClick = onGetCode,
                        icon = {
                            Icon(Icons.Default.Code, contentDescription = null, modifier = Modifier.size(16.dp))
                        }
                    )
                }

                // Round black "↗" button at the bottom right
                RoundBlackDocsButton(url = api.docsUrl)
            }
        }
    }
}

@Composable
fun LockedProCard(
    onUnlock: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .graphicsLayer(rotationZ = -2f)
            .testTag("locked_pro_card"),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = AppCoral),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "LOCKED PRO FEATURE",
                    color = AppBackground,
                    fontSize = 18.sp,
                    fontFamily = ArchivoFontFamily,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = (-0.5).sp
                )
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = null,
                    tint = AppBackground,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "Watchlists, 24/7 downtime alerts, server-side CORS tests, and full project scaffold exports are exclusive to APIMatch Pro.",
                color = AppBackground,
                fontSize = 15.sp,
                fontFamily = ArchivoFontFamily,
                fontWeight = FontWeight.Medium,
                lineHeight = 21.sp
            )

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = onUnlock,
                shape = RoundedCornerShape(24.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = AppBackground,
                    contentColor = AppWhite
                ),
                modifier = Modifier.fillMaxWidth().height(48.dp)
            ) {
                Text(
                    text = "UNLOCK WITH PRO",
                    fontSize = 14.sp,
                    fontFamily = ArchivoFontFamily,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 0.5.sp
                )
            }
        }
    }
}

@Composable
fun SagePaywallBottomSheet(
    reason: String,
    onUpgrade: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedPlan by remember { mutableStateOf("yearly") } // "monthly" vs "yearly"

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.9f)
                .testTag("sage_paywall_sheet"),
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = AppSage),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(24.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "GO PRO",
                        color = AppBackground,
                        fontSize = 32.sp,
                        fontFamily = ArchivoFontFamily,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = (-0.5).sp
                    )

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(AppBackground)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = AppWhite, modifier = Modifier.size(18.dp))
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = reason,
                    color = AppBackground,
                    fontSize = 15.sp,
                    fontFamily = ArchivoFontFamily,
                    fontWeight = FontWeight.Medium,
                    lineHeight = 20.sp
                )

                Spacer(modifier = Modifier.height(18.dp))

                // Selector: Monthly $10 vs Yearly $96 (yellow = selected)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Yearly card
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { selectedPlan = "yearly" },
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (selectedPlan == "yearly") AppYellow else AppCardNav
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "YEARLY",
                                color = if (selectedPlan == "yearly") AppBackground else AppWhite,
                                fontSize = 14.sp,
                                fontFamily = ArchivoFontFamily,
                                fontWeight = FontWeight.ExtraBold
                            )
                            Text(
                                text = "$96 / YEAR",
                                color = if (selectedPlan == "yearly") AppBackground else AppWhite,
                                fontSize = 18.sp,
                                fontFamily = ArchivoFontFamily,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                text = "2 MONTHS FREE",
                                color = if (selectedPlan == "yearly") AppCoral else AppYellow,
                                fontSize = 11.sp,
                                fontFamily = ArchivoFontFamily,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }

                    // Monthly card
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { selectedPlan = "monthly" },
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (selectedPlan == "monthly") AppYellow else AppCardNav
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "MONTHLY",
                                color = if (selectedPlan == "monthly") AppBackground else AppWhite,
                                fontSize = 14.sp,
                                fontFamily = ArchivoFontFamily,
                                fontWeight = FontWeight.ExtraBold
                            )
                            Text(
                                text = "$10 / MO",
                                color = if (selectedPlan == "monthly") AppBackground else AppWhite,
                                fontSize = 18.sp,
                                fontFamily = ArchivoFontFamily,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                text = "FLEXIBLE CANCEL",
                                color = if (selectedPlan == "monthly") AppBackground else AppWhite.copy(alpha = 0.7f),
                                fontSize = 11.sp,
                                fontFamily = ArchivoFontFamily,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // 4 Benefits
                Text(
                    text = "PRO PERKS",
                    color = AppBackground,
                    fontSize = 14.sp,
                    fontFamily = ArchivoFontFamily,
                    fontWeight = FontWeight.ExtraBold
                )
                Spacer(modifier = Modifier.height(10.dp))

                val benefits = listOf(
                    "UNLIMITED AI MATCHES" to "Never hit the 5 search daily cap.",
                    "DOWNTIME WATCHLIST" to "Get push alerts when your APIs go down.",
                    "FULL PROJECT SCAFFOLDS" to "Download full project code & configs.",
                    "SERVER-SIDE CORS PROXY" to "Bypass mobile client CORS restrictions."
                )

                benefits.forEach { (title, desc) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Text("•", color = AppBackground, fontSize = 18.sp, fontWeight = FontWeight.Black)
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = title,
                                color = AppBackground,
                                fontSize = 13.sp,
                                fontFamily = ArchivoFontFamily,
                                fontWeight = FontWeight.ExtraBold
                            )
                            Text(
                                text = desc,
                                color = AppBackground.copy(alpha = 0.8f),
                                fontSize = 12.sp,
                                fontFamily = ArchivoFontFamily,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Black button "Start 7-day free trial"
                Button(
                    onClick = {
                        onUpgrade(if (selectedPlan == "yearly") "Yearly ($96/yr)" else "Monthly ($10/mo)")
                    },
                    shape = RoundedCornerShape(26.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = AppBackground,
                        contentColor = AppWhite
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("start_free_trial_button")
                ) {
                    Text(
                        text = "START 7-DAY FREE TRIAL",
                        fontSize = 14.sp,
                        fontFamily = ArchivoFontFamily,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 0.5.sp
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Cancel anytime. Zero risk.",
                    color = AppBackground.copy(alpha = 0.7f),
                    fontSize = 11.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
fun StarterCodeModal(
    api: PublicApi,
    isPro: Boolean,
    selectedLang: String,
    selectedTab: Int,
    onLangSelected: (String) -> Unit,
    onTabSelected: (Int) -> Unit,
    onExportZip: () -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val snippet = remember(api, selectedLang) {
        StarterCodeGenerator.generateSnippet(api, selectedLang)
    }
    val scaffold = remember(api, selectedLang) {
        StarterCodeGenerator.generateFullProjectScaffold(api, selectedLang)
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f),
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = AppCardNav),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(22.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "STARTER CODE",
                            color = AppWhite,
                            fontSize = 20.sp,
                            fontFamily = ArchivoFontFamily,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = api.name.uppercase(),
                            color = AppYellow,
                            fontSize = 12.sp,
                            fontFamily = ArchivoFontFamily,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(AppBackground)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = AppWhite, modifier = Modifier.size(16.dp))
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Tab Switcher: Free Snippet vs Pro Scaffold
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(AppBackground)
                        .padding(4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (selectedTab == 0) AppCoral else Color.Transparent)
                            .clickable { onTabSelected(0) }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "SNIPPET (FREE)",
                            color = if (selectedTab == 0) AppBackground else AppWhite,
                            fontSize = 11.sp,
                            fontFamily = ArchivoFontFamily,
                            fontWeight = FontWeight.Black
                        )
                    }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (selectedTab == 1) AppCoral else Color.Transparent)
                            .clickable { onTabSelected(1) }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "SCAFFOLD (PRO)",
                                color = if (selectedTab == 1) AppBackground else AppWhite,
                                fontSize = 11.sp,
                                fontFamily = ArchivoFontFamily,
                                fontWeight = FontWeight.Black
                            )
                            if (!isPro) {
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(
                                    Icons.Default.Lock,
                                    contentDescription = "Pro",
                                    tint = if (selectedTab == 1) AppBackground else AppCoral,
                                    modifier = Modifier.size(12.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Language pills
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("JavaScript", "Python", "Dart").forEach { lang ->
                        val isSelected = selectedLang.equals(lang, ignoreCase = true)
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(if (isSelected) AppSage else AppBackground)
                                .clickable { onLangSelected(lang) }
                                .padding(horizontal = 14.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = lang.uppercase(),
                                color = if (isSelected) AppBackground else AppWhite,
                                fontSize = 11.sp,
                                fontFamily = ArchivoFontFamily,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Code display container
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(AppBackground)
                        .padding(14.dp)
                ) {
                    val codeContent = if (selectedTab == 0) snippet else scaffold
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                    ) {
                        Text(
                            text = codeContent,
                            color = AppWhite,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            lineHeight = 16.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    SecondaryPillButton(
                        text = "COPY CODE",
                        onClick = {
                            val textToCopy = if (selectedTab == 0) snippet else scaffold
                            clipboardManager.setText(AnnotatedString(textToCopy))
                            Toast.makeText(context, "Code copied to clipboard!", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.weight(1f),
                        icon = {
                            Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                        }
                    )

                    if (selectedTab == 1) {
                        PrimaryPillButton(
                            text = "EXPORT ZIP",
                            onClick = onExportZip,
                            modifier = Modifier.weight(1f),
                            icon = {
                                Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp), tint = AppBackground)
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ProfileModalSheet(
    viewModel: MainViewModel,
    onDismiss: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f),
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = AppCardNav),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(24.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "DEV PROFILE",
                        color = AppWhite,
                        fontSize = 24.sp,
                        fontFamily = ArchivoFontFamily,
                        fontWeight = FontWeight.ExtraBold
                    )
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(AppBackground)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = AppWhite, modifier = Modifier.size(16.dp))
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Avatar card
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = AppBackground),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .background(AppYellow),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = uiState.userEmail?.take(1)?.uppercase() ?: "D",
                                color = AppBackground,
                                fontSize = 22.sp,
                                fontFamily = ArchivoFontFamily,
                                fontWeight = FontWeight.Black
                            )
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column {
                            Text(
                                text = uiState.userEmail ?: "developer@apimatch.dev",
                                color = AppWhite,
                                fontSize = 15.sp,
                                fontFamily = ArchivoFontFamily,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (uiState.isPro) "PRO MEMBER" else "FREE TIER (5/DAY)",
                                color = if (uiState.isPro) AppBlue else AppYellow,
                                fontSize = 12.sp,
                                fontFamily = ArchivoFontFamily,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Sign in / Sign out
                if (uiState.userEmail == null) {
                    PrimaryPillButton(
                        text = "SIGN IN WITH GOOGLE",
                        onClick = { viewModel.signInWithGoogle(context) },
                        modifier = Modifier.fillMaxWidth()
                    )
                } else {
                    SecondaryPillButton(
                        text = "SIGN OUT",
                        onClick = { viewModel.signOut() },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Stats
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Card(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = AppBackground)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text("${uiState.streakDays} DAYS", color = AppYellow, fontSize = 18.sp, fontFamily = ArchivoFontFamily, fontWeight = FontWeight.Black)
                            Text("ACTIVE STREAK", color = AppWhite.copy(alpha = 0.7f), fontSize = 10.sp, fontFamily = ArchivoFontFamily, fontWeight = FontWeight.Bold)
                        }
                    }
                    Card(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = AppBackground)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text("${uiState.apisTestedCount}", color = AppSage, fontSize = 18.sp, fontFamily = ArchivoFontFamily, fontWeight = FontWeight.Black)
                            Text("APIS TESTED", color = AppWhite.copy(alpha = 0.7f), fontSize = 10.sp, fontFamily = ArchivoFontFamily, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Export Full Project Source Code / ZIP
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = AppBackground),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "EXPORT APP PROJECT ZIP",
                            color = AppWhite,
                            fontSize = 14.sp,
                            fontFamily = ArchivoFontFamily,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Download the complete APIMatch application archive with all Kotlin code, resources, and Gradle build files.",
                            color = AppWhite.copy(alpha = 0.8f),
                            fontSize = 12.sp,
                            fontFamily = ArchivoFontFamily,
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        PrimaryPillButton(
                            text = "EXPORT APPLICATION ZIP",
                            onClick = {
                                val dummyApi = ApiCatalogSeed.apis[0]
                                viewModel.exportScaffoldZip(context, dummyApi)
                            },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun EmailCaptureDialog(
    onSaveEmail: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var emailInput by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = AppCardNav),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "SAVE YOUR MATCHES",
                    color = AppWhite,
                    fontSize = 20.sp,
                    fontFamily = ArchivoFontFamily,
                    fontWeight = FontWeight.Black
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Enter your email to sync your matching APIs and starter code across all devices.",
                    color = AppWhite.copy(alpha = 0.75f),
                    fontSize = 14.sp,
                    fontFamily = ArchivoFontFamily,
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = emailInput,
                    onValueChange = { emailInput = it },
                    placeholder = { Text("dev@company.com", color = AppWhite.copy(alpha = 0.4f)) },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = AppBackground,
                        unfocusedContainerColor = AppBackground,
                        focusedBorderColor = Color.Transparent,
                        unfocusedBorderColor = Color.Transparent,
                        focusedTextColor = AppWhite,
                        unfocusedTextColor = AppWhite
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(18.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    SecondaryPillButton(
                        text = "LATER",
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    )
                    PrimaryPillButton(
                        text = "SAVE",
                        onClick = { onSaveEmail(emailInput) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@Composable
fun WeeklyDigestDialog(onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f),
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = AppCardNav),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(24.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "WEEKLY DIGEST",
                        color = AppWhite,
                        fontSize = 22.sp,
                        fontFamily = ArchivoFontFamily,
                        fontWeight = FontWeight.Black
                    )
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(AppBackground)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = AppWhite, modifier = Modifier.size(16.dp))
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "3 NEW FREE APIS MATCHING YOUR PROJECTS",
                    color = AppYellow,
                    fontSize = 13.sp,
                    fontFamily = ArchivoFontFamily,
                    fontWeight = FontWeight.ExtraBold
                )

                Spacer(modifier = Modifier.height(12.dp))

                val items = listOf(
                    Triple("Jolpica F1 API", "Sports & Racing", AppBlue),
                    Triple("disease.sh", "Health & Open Data", AppCoral),
                    Triple("Ollama Local REST", "AI & ML", AppSage)
                )

                items.forEach { (name, cat, color) ->
                    val contentColor = getCardContentColor(color)
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = color),
                        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(name.uppercase(), color = contentColor, fontSize = 16.sp, fontFamily = ArchivoFontFamily, fontWeight = FontWeight.Black)
                            Text(cat.uppercase(), color = contentColor.copy(alpha = 0.8f), fontSize = 11.sp, fontFamily = ArchivoFontFamily, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CancellationFlowDialog(
    onPauseMonth: () -> Unit,
    onClaimDiscount: () -> Unit,
    onConfirmCancel: () -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = AppCardNav),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "BEFORE YOU GO...",
                    color = AppWhite,
                    fontSize = 20.sp,
                    fontFamily = ArchivoFontFamily,
                    fontWeight = FontWeight.Black
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Pause your subscription for 1 month for free or claim 50% off your next 3 billing cycles.",
                    color = AppWhite.copy(alpha = 0.75f),
                    fontSize = 14.sp,
                    fontFamily = ArchivoFontFamily,
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(18.dp))

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onPauseMonth,
                        shape = RoundedCornerShape(24.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = AppSage, contentColor = AppBackground),
                        modifier = Modifier.fillMaxWidth().height(46.dp)
                    ) {
                        Text("PAUSE 1 MONTH (FREE)", fontFamily = ArchivoFontFamily, fontWeight = FontWeight.ExtraBold)
                    }

                    Button(
                        onClick = onClaimDiscount,
                        shape = RoundedCornerShape(24.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = AppYellow, contentColor = AppBackground),
                        modifier = Modifier.fillMaxWidth().height(46.dp)
                    ) {
                        Text("CLAIM 50% OFF (3 MONTHS)", fontFamily = ArchivoFontFamily, fontWeight = FontWeight.ExtraBold)
                    }

                    TextButton(onClick = onConfirmCancel, modifier = Modifier.fillMaxWidth()) {
                        Text("Continue Cancellation", color = AppCoral, fontSize = 12.sp, fontFamily = ArchivoFontFamily, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
