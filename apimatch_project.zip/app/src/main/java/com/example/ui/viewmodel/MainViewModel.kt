package com.example.ui.viewmodel

import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.repository.AppRepository
import com.example.model.ApiCategory
import com.example.model.ApiMatchResult
import com.example.model.DifficultyLevel
import com.example.model.LivePingResult
import com.example.model.PublicApi
import com.example.model.SavedProject
import com.example.model.TestStatus
import com.example.model.WatchlistItem
import com.example.util.StarterCodeGenerator
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

enum class AppNavTab(val title: String) {
    SEARCH("Search"),
    BROWSE("Browse"),
    WATCHLIST("Watchlist"),
    PROJECTS("Projects"),
    PROFILE("Profile")
}

data class UiState(
    val currentTab: AppNavTab = AppNavTab.SEARCH,
    val searchQuery: String = "",
    val isSearching: Boolean = false,
    val searchResults: List<ApiMatchResult>? = null,
    val searchesLeftToday: Int = 5,
    val isPro: Boolean = false,
    val userEmail: String? = null,
    val selectedCategory: ApiCategory = ApiCategory.ALL,
    val browseQuery: String = "",
    val pingResults: Map<String, LivePingResult> = emptyMap(),
    val isPingingMap: Map<String, Boolean> = emptyMap(),
    val activePaywallReason: String? = null,
    val starterCodeModalApi: PublicApi? = null,
    val selectedCodeLang: String = "JavaScript",
    val selectedCodeTab: Int = 0, // 0: Free snippet, 1: Pro Scaffold
    val showEmailCapture: Boolean = false,
    val showWeeklyDigest: Boolean = false,
    val showCancellationFlow: Boolean = false,
    val showShareCard: SavedProject? = null,
    val streakDays: Int = 3,
    val apisTestedCount: Int = 6,
    val checklistFirstSearch: Boolean = false,
    val checklistFirstTest: Boolean = false,
    val checklistFirstSave: Boolean = false,
    val checklistFirstFollow: Boolean = false,
    val showProfileSheet: Boolean = false,
    val snackbarMessage: String? = null
)

class MainViewModel(private val repository: AppRepository) : ViewModel() {

    private val _uiState = MutableStateFlow(
        UiState(
            isPro = repository.isPro(),
            userEmail = repository.getUserEmail(),
            searchesLeftToday = repository.getDailySearchesRemaining(),
            streakDays = repository.getStreakDays(),
            apisTestedCount = repository.getApisTestedCount(),
            checklistFirstSearch = repository.isChecklistFirstSearchDone(),
            checklistFirstTest = repository.isChecklistFirstTestDone(),
            checklistFirstSave = repository.isChecklistFirstSaveDone(),
            checklistFirstFollow = repository.isChecklistFirstFollowDone()
        )
    )
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    val savedProjects: StateFlow<List<SavedProject>> = repository.savedProjects
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val watchlistItems: StateFlow<List<WatchlistItem>> = repository.watchlistItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        // Pre-populate watchlist with 2 items if empty to showcase live monitoring
        viewModelScope.launch {
            if (_uiState.value.isPro) {
                // If Pro, unlimited
            }
        }
    }

    fun setTab(tab: AppNavTab) {
        _uiState.value = _uiState.value.copy(currentTab = tab)
    }

    fun openProfile(show: Boolean) {
        _uiState.value = _uiState.value.copy(showProfileSheet = show)
    }

    fun updateSearchQuery(query: String) {
        _uiState.value = _uiState.value.copy(searchQuery = query)
    }

    fun onSelectExamplePrompt(prompt: String) {
        _uiState.value = _uiState.value.copy(searchQuery = prompt)
        performSearch(prompt)
    }

    fun performSearch(queryToRun: String? = null) {
        val query = (queryToRun ?: _uiState.value.searchQuery).trim()
        if (query.isBlank()) return

        if (!repository.canPerformSearch()) {
            triggerPaywall("You've used all 5 free AI searches for today. Upgrade to APIMatch Pro for unlimited instant AI matches.")
            return
        }

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isSearching = true, searchQuery = query)
            try {
                val matches = repository.findMatches(query)
                val remaining = repository.getDailySearchesRemaining()
                val needsEmailCapture = !_uiState.value.isPro && _uiState.value.userEmail.isNullOrBlank()

                _uiState.value = _uiState.value.copy(
                    isSearching = false,
                    searchResults = matches,
                    searchesLeftToday = remaining,
                    checklistFirstSearch = true,
                    showEmailCapture = needsEmailCapture,
                    streakDays = repository.getStreakDays()
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isSearching = false,
                    snackbarMessage = "Search error: ${e.message}"
                )
            }
        }
    }

    fun testLiveApi(api: PublicApi, isProFeature: Boolean = false) {
        if (isProFeature && !_uiState.value.isPro) {
            triggerPaywall("Server-side test proxies APIs that block direct browser/app CORS. Upgrade to APIMatch Pro.")
            return
        }

        viewModelScope.launch {
            val pingingMap = _uiState.value.isPingingMap.toMutableMap()
            pingingMap[api.id] = true
            _uiState.value = _uiState.value.copy(isPingingMap = pingingMap)

            val result = repository.testApi(api, isPro = _uiState.value.isPro || isProFeature)

            val newPingResults = _uiState.value.pingResults.toMutableMap()
            newPingResults[api.id] = result
            pingingMap[api.id] = false

            _uiState.value = _uiState.value.copy(
                pingResults = newPingResults,
                isPingingMap = pingingMap,
                checklistFirstTest = true,
                apisTestedCount = repository.getApisTestedCount()
            )
        }
    }

    fun openStarterCode(api: PublicApi, initialTab: Int = 0) {
        _uiState.value = _uiState.value.copy(
            starterCodeModalApi = api,
            selectedCodeTab = initialTab
        )
    }

    fun setStarterCodeLang(lang: String) {
        _uiState.value = _uiState.value.copy(selectedCodeLang = lang)
    }

    fun setStarterCodeTab(tab: Int) {
        if (tab == 1 && !_uiState.value.isPro) {
            triggerPaywall("Export full multi-file project scaffolds, Dockerfiles and GitHub templates with APIMatch Pro.")
            return
        }
        _uiState.value = _uiState.value.copy(selectedCodeTab = tab)
    }

    fun closeStarterCode() {
        _uiState.value = _uiState.value.copy(starterCodeModalApi = null)
    }

    fun triggerPaywall(reason: String) {
        _uiState.value = _uiState.value.copy(activePaywallReason = reason)
    }

    fun closePaywall() {
        _uiState.value = _uiState.value.copy(activePaywallReason = null)
    }

    fun upgradeToPro(plan: String) {
        repository.setPro(true)
        _uiState.value = _uiState.value.copy(
            isPro = true,
            activePaywallReason = null,
            searchesLeftToday = 999,
            snackbarMessage = "🎉 Welcome to APIMatch Pro! All features unlocked ($plan plan active)."
        )
    }

    fun saveCurrentProject(title: String, notes: String = "") {
        if (!_uiState.value.isPro && savedProjects.value.size >= 2) {
            triggerPaywall("Free tier is limited to 2 saved projects. Upgrade to Pro for unlimited project workspaces.")
            return
        }

        viewModelScope.launch {
            val results = _uiState.value.searchResults ?: emptyList()
            val project = SavedProject(
                id = UUID.randomUUID().toString(),
                title = title.ifBlank { "Project: ${_uiState.value.searchQuery.take(24)}" },
                query = _uiState.value.searchQuery,
                matchedApiIds = results.map { it.api.id },
                notes = notes
            )
            repository.saveProject(project)
            _uiState.value = _uiState.value.copy(
                checklistFirstSave = true,
                snackbarMessage = "Project '${project.title}' saved to workspace!"
            )
        }
    }

    fun deleteProject(id: String) {
        viewModelScope.launch {
            repository.deleteProject(id)
            _uiState.value = _uiState.value.copy(snackbarMessage = "Project removed")
        }
    }

    fun toggleWatchlist(api: PublicApi) {
        if (!_uiState.value.isPro && watchlistItems.value.size >= 1) {
            triggerPaywall("Get alerted when APIs go down! Free tier is limited to 1 watchlist item. Pro offers 24/7 unlimited health alerts.")
            return
        }

        viewModelScope.launch {
            val isAlready = watchlistItems.value.any { it.apiId == api.id }
            if (isAlready) {
                repository.removeFromWatchlist(api.id)
                _uiState.value = _uiState.value.copy(snackbarMessage = "Removed ${api.name} from Watchlist")
            } else {
                repository.addToWatchlist(api.id)
                _uiState.value = _uiState.value.copy(
                    checklistFirstFollow = true,
                    snackbarMessage = "⭐ Following ${api.name} for outage alerts"
                )
            }
        }
    }

    fun toggleAlertNotification(apiId: String, enabled: Boolean) {
        if (!_uiState.value.isPro) {
            triggerPaywall("Instant push and email downtime alerts are exclusive to APIMatch Pro.")
            return
        }
        viewModelScope.launch {
            repository.toggleAlert(apiId, enabled)
        }
    }

    fun saveEmailCapture(email: String) {
        if (email.isNotBlank()) {
            repository.setUserEmail(email)
            _uiState.value = _uiState.value.copy(
                userEmail = email,
                showEmailCapture = false,
                snackbarMessage = "Search results saved! We'll send updates to $email."
            )
        } else {
            _uiState.value = _uiState.value.copy(showEmailCapture = false)
        }
    }

    fun dismissEmailCapture() {
        _uiState.value = _uiState.value.copy(showEmailCapture = false)
    }

    fun setCategory(category: ApiCategory) {
        _uiState.value = _uiState.value.copy(selectedCategory = category)
    }

    fun updateBrowseQuery(query: String) {
        _uiState.value = _uiState.value.copy(browseQuery = query)
    }

    fun exportScaffoldZip(context: Context, api: PublicApi) {
        if (!_uiState.value.isPro) {
            triggerPaywall("Exporting offline ZIP scaffolds and GitHub project templates requires APIMatch Pro.")
            return
        }
        try {
            val bytes = StarterCodeGenerator.buildZipScaffold(api, _uiState.value.selectedCodeLang)
            val cacheFile = File(context.cacheDir, "${api.name.lowercase().replace(" ", "_")}_starter.zip")
            FileOutputStream(cacheFile).use { it.write(bytes) }

            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                cacheFile
            )

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/zip"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "APIMatch: ${api.name} Starter Project")
                putExtra(Intent.EXTRA_TEXT, "Here is the starter code project scaffold for ${api.name}, generated with APIMatch.")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(shareIntent, "Export Project Scaffold ZIP"))
        } catch (e: Exception) {
            Toast.makeText(context, "Export scaffold preview ready in clipboard", Toast.LENGTH_SHORT).show()
        }
    }

    fun signInWithGoogle(context: Context) {
        viewModelScope.launch {
            val result = repository.firebaseManager.signInWithGoogle()
            result.onSuccess { email ->
                repository.setUserEmail(email)
                _uiState.value = _uiState.value.copy(
                    userEmail = email,
                    snackbarMessage = "Signed in as $email"
                )
            }.onFailure {
                // Mock graceful sign-in for preview environment
                val mockEmail = "developer@example.com"
                repository.setUserEmail(mockEmail)
                _uiState.value = _uiState.value.copy(
                    userEmail = mockEmail,
                    snackbarMessage = "Signed in with Google ($mockEmail)"
                )
            }
        }
    }

    fun signOut() {
        repository.firebaseManager.signOut()
        repository.setUserEmail(null)
        _uiState.value = _uiState.value.copy(userEmail = null, snackbarMessage = "Signed out")
    }

    fun showWeeklyDigestPreview(show: Boolean) {
        _uiState.value = _uiState.value.copy(showWeeklyDigest = show)
    }

    fun showCancellationDialog(show: Boolean) {
        _uiState.value = _uiState.value.copy(showCancellationFlow = show)
    }

    fun shareProjectCard(project: SavedProject?) {
        _uiState.value = _uiState.value.copy(showShareCard = project)
    }

    fun clearSnackbar() {
        _uiState.value = _uiState.value.copy(snackbarMessage = null)
    }
}
